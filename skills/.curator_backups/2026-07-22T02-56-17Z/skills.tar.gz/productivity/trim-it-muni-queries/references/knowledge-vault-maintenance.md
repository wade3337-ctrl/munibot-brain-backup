# Knowledge Vault Maintenance — Self-Improvement Protocol

Muni Bot maintains its own knowledge through two automated mechanisms plus
a standing rule to surface them at chat start. Set by the Skipper, 2026-07-17.

## The Three Components

### 1. End-of-Day Knowledge Sweep (nightly, 11 PM PT)

**Cron job:** `bf46e2d41835` — "End-of-Day Knowledge Sweep"
**Schedule:** `0 6 * * *` (6:00 AM UTC = 11:00 PM Pacific)

**What it does:**
- Reviews all sessions from the last 24 hours
- Identifies genuinely new learnings (TRIM IT gotchas, query patterns, Brent
  preferences, municipal facts, workflow discoveries)
- Writes each as a NEW atomic note in the vault (`concepts/` or `references/`)
- Patches the skill's Common Pitfalls list if new query/schema issues were found
- Commits to git
- Goes silent (`[SILENT]`) if nothing new was learned

**What NOT to capture** (transient, not durable):
- Environment-dependent failures (missing binaries, path mismatches)
- Session-specific errors that resolved on retry
- One-off task narratives
- Negative claims about tools ("X doesn't work")

### 2. Weekly Vault Housekeeping (Sundays, 9 AM PT)

**Cron job:** `f7f5d8f8586d` — "Weekly Vault Housekeeping"
**Schedule:** `0 16 * * 0` (4:00 PM UTC = 9:00 AM Pacific Sunday)

**What it does:**
- Scans the vault for orphaned files (no incoming wikilinks, not foundational)
- Identifies duplicate/overlapping notes
- Flags stale info (60+ days old with specific data that may have changed)
- Archives to `_archive/` (NEVER deletes) with a reason header
- Updates README.md and skill references to remove dead links
- Goes silent if the vault is already clean

**Foundational files (never archive):**
- `00-start-here/README.md`
- `references/brent-profile.md`
- Anything in `brent-history/`

**Conservative rule:** when unsure whether something is orphaned or duplicate,
LEAVE IT IN PLACE and note it for review.

### 3. Standing Rule (visible at every chat start)

Both maintenance rules are saved in user-profile memory so they're injected
into every new session. This ensures the agent knows about the maintenance
schedule even if a cron job is paused or fails.

## Vault Structure Reference

```
/opt/data/home/municipal-knowledge/
├── 00-start-here/README.md     ← vault map with [[wikilinks]]
├── concepts/                   ← rules, how-it-works (NEW notes go here)
├── references/                 ← facts, lookups, detailed workflows
├── query-playbook/             ← verified SQL patterns
├── brent-history/              ← ingested source documents
├── _archive/                   ← archived files (never deleted)
└── .git/                       ← version-controlled
```

**Path warning:** always use the absolute path `/opt/data/home/municipal-knowledge/`.
The `~/home/` shorthand expands to `/opt/data/home/home/` (double path) because
`$HOME=/opt/data`.

**Git identity (per-repo):**
```bash
cd /opt/data/home/municipal-knowledge
git config user.email "MuniBot.gsts@gmail.com"
git config user.name "Muni Bot"
```

## Atomic Note Writing Rules

When writing a NEW note (from the nightly sweep or during a session):

1. **Location:** `concepts/` for rules/how-it-works, `references/` for facts/lookups
2. **Filename:** fresh kebab-case (e.g. `maps-locationid-join-gotcha.md`)
3. **Frontmatter:** `title`, `type`, `tags`, `updated` (today's date)
4. **Body:** include `[[wikilinks]]` to cross-link related notes
5. **Write NEW notes — don't edit existing curated ones** (new notes are
   auto-collected to the shared vault; edits to existing notes are not)
6. **Track-1 only** — never write arbor-core / Track-2 / confidential material

## Cron Job Management

To check job status:
```
cronjob action=list
```

To pause/resume a sweep:
```
cronjob action=pause job_id=bf46e2d41835    # nightly sweep
cronjob action=pause job_id=f7f5d8f8586d    # weekly housekeeping
```

To run manually (e.g. after a big session):
```
cronjob action=run job_id=bf46e2d41835
```
